from discord.ext.commands import Bot


class AutoBot(Bot):
  ...